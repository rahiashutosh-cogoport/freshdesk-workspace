'use strict';
const details_get_url = 'https://uat-api.cogoport.com/api/v1/organizations/profile';

$(document).ready(function() {
  app.initialized()
  .then(function(_client) {
    var client = _client;
    var userData = {};
    var url = details_get_url;
    client.instance.context()
    .then(function(context) {
      userData = context.data;
      url = url + '?email=' + userData.email;
      console.log('URL=', url);
    //   client.request.get(url, {})
    //     .then(
    //         function(data) {
    //             // toastr.info(data.response);
    //             console.log('DATA RECEIVED=', data);
    //             console.log('DATA STATUS=', data.status);
    //             console.log('DATA RESPONSE=', data.response);

    //             if(data.status) {

    //             }
    //         },
    //         function(error) {
    //             console.error('ERROR: ', error);
    //         }
    //     );
      var template = '<div class="ticket-title"><span style="color: dodgerblue">${name}</span><br />\
                      <span style="color: dodgerblue">${email}</span>\
                      </div>';

      $.tmpl( template, userData).appendTo('#user_name');
    });

    

    // $('.manage-bookmarks').on('click', '.remove-bookmark', function() {
    //   var ticketId = $(this).parents('.manage-bm-li').data('ticketId');
    //   $(this).parents('.manage-bm-li').remove();
    //   client.instance.send({ 
    //     message: {type: 'removeTicket', ticketId: ticketId}
    //   }); 
    // });
  });
});